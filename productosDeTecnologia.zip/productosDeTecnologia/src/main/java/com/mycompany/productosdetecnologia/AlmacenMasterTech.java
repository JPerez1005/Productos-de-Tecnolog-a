package com.mycompany.productosdetecnologia;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class AlmacenMasterTech {
    private Map<Integer, String> categorias = new HashMap<>();
    private Map<Integer, Producto> inventario = new HashMap<>();

    public static void main(String[] args) {
        AlmacenMasterTech almacen = new AlmacenMasterTech();
        almacen.iniciarPrograma();
    }

    public void iniciarPrograma() {
    // Inicializar categorías
    inicializarCategorias();

    Scanner scanner = new Scanner(System.in);
    int opcion=0;

    do {
        try {
            System.out.println("----- Menú Principal -----");
            System.out.println("1. Añadir Producto");
            System.out.println("2. Eliminar Producto");
            System.out.println("3. Mostrar Inventario por Categoría");
            System.out.println("4. Añadir Categoría");
            System.out.println("5. Eliminar Categoría");
            System.out.println("6. Salir");
            System.out.print("Seleccione una opción: ");
            
            opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    añadirProducto(scanner);
                    break;
                case 2:
                    eliminarProducto(scanner);
                    break;
                case 3:
                    mostrarInventarioPorCategoria(scanner);
                    break;
                case 4:
                    añadirCategoria(scanner);
                    break;
                case 5:
                    eliminarCategoria(scanner);
                    break;
                case 6:
                    System.out.println("Saliendo del programa. ¡Hasta luego!");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtelo de nuevo.");
            }
        } catch (Exception e) {
            System.out.println("Error: Entrada inválida. Asegúrate de ingresar un número entero válido.");
            scanner.nextLine(); // Limpiar el buffer del scanner
        }

    } while (opcion != 6);
}
    
    private void inicializarCategorias() {
        categorias.put(1, "Computadores");
        categorias.put(2, "Celulares");
        categorias.put(3, "Electrodomésticos");
        categorias.put(4, "TV");
        categorias.put(5, "Accesorios");
        categorias.put(6, "Videojuegos");
        categorias.put(7, "Audio y video");
    }
    
    private void añadirProducto(Scanner scanner) {
    System.out.println("----- Añadir Producto -----");

    try {
        // Leer detalles del producto
        System.out.print("Nombre del producto: ");
        String nombre = scanner.next();

        System.out.print("Precio: ");
        double precio = scanner.nextDouble();

        System.out.print("Número de referencia: ");
        int referencia = scanner.nextInt();

        // Verificar si ya existe un producto con la misma referencia
        if (inventario.containsKey(referencia)) {
            System.out.println("Error: Ya existe un producto con el mismo número de referencia.");
            return;
        }

        System.out.print("Cantidad disponible: ");
        int cantidad = scanner.nextInt();

        // Leer y mostrar categorías disponibles
        System.out.println("Categorías disponibles:");
        categorias.forEach((key, value) -> System.out.println(key + ": " + value));

        System.out.print("Seleccione la categoría del producto: ");
        int categoria = scanner.nextInt();

        // Verificar si la categoría es válida
        if (!categorias.containsKey(categoria)) {
            System.out.println("Error: Categoría no válida.");
            return;
        }

        // Crear y añadir el producto al inventario
        Producto nuevoProducto = new Producto(nombre, precio, referencia, cantidad, categoria);
        inventario.put(referencia, nuevoProducto);

        System.out.println("Producto añadido correctamente.");

    } catch (Exception e) {
        System.out.println("Error: Entrada inválida. Asegúrate de ingresar datos válidos.");
        // Puedes agregar más detalles sobre la excepción en un entorno de producción
    }
}
    
    private void eliminarProducto(Scanner scanner) {
        System.out.println("----- Eliminar Producto -----");
        try {
            System.out.print("Ingrese el número de referencia del producto a eliminar: ");
            int referencia = scanner.nextInt();

            // Verificar si el producto existe en el inventario
            if (inventario.containsKey(referencia)) {
                // Eliminar el producto
                inventario.remove(referencia);
                System.out.println("Producto eliminado correctamente.");
            } else {
                System.out.println("Error: El producto con el número de referencia dado no existe en el inventario.");
            }
        } catch (Exception e) {
            System.out.println("Error: Entrada inválida. Asegúrate de ingresar un número entero válido.");
        }
    }

    private void mostrarInventarioPorCategoria(Scanner scanner) {
        System.out.println("----- Mostrar Inventario por Categoría -----");
        try {
            // Leer y mostrar categorías disponibles
            System.out.println("Categorías disponibles:");
            categorias.forEach((key, value) -> System.out.println(key + ": " + value));

            System.out.print("Seleccione la categoría para mostrar el inventario: ");
            int categoriaSeleccionada = scanner.nextInt();

            // Verificar si la categoría seleccionada es válida
            if (categorias.containsKey(categoriaSeleccionada)) {
                // Mostrar productos de la categoría seleccionada
                System.out.println("Inventario para la categoría '" + categorias.get(categoriaSeleccionada) + "':");
                inventario.forEach((key, producto) -> {
                    if (producto.categoria == categoriaSeleccionada) {
                        System.out.println("Nombre: " + producto.nombre + ", Precio: " + producto.precio + ", Cantidad: " + producto.cantidad);
                    }
                });
            } else {
                System.out.println("Error: Categoría no válida.");
            }
        } catch (Exception e) {
            System.out.println("Error: Entrada inválida. Asegúrate de ingresar un número entero válido.");
        }
    }

    private void añadirCategoria(Scanner scanner) {
        System.out.println("----- Añadir Categoría -----");
        try {
            System.out.print("Ingrese el número de la nueva categoría: ");
            int numeroCategoria = scanner.nextInt();

            // Verificar si la categoría ya existe
            if (categorias.containsKey(numeroCategoria)) {
                System.out.println("Error: La categoría ya existe.");
            } else {
                System.out.print("Ingrese el nombre de la nueva categoría: ");
                String nombreCategoria = scanner.next();

                // Añadir la nueva categoría al mapa de categorías
                categorias.put(numeroCategoria, nombreCategoria);
                System.out.println("Categoría añadida correctamente.");
            }
        } catch (Exception e) {
            System.out.println("Error: Entrada inválida. Asegúrate de ingresar un número entero válido.");
        }
    }

    private void eliminarCategoria(Scanner scanner) {
        System.out.println("----- Eliminar Categoría -----");
        try {
            System.out.print("Ingrese el número de la categoría a eliminar: ");
            int numeroCategoria = scanner.nextInt();

            // Verificar si la categoría existe
            if (categorias.containsKey(numeroCategoria)) {
                // Eliminar la categoría
                categorias.remove(numeroCategoria);

                // Actualizar productos en el inventario que pertenecen a la categoría eliminada
                inventario.entrySet().removeIf(entry -> entry.getValue().categoria == numeroCategoria);

                System.out.println("Categoría eliminada correctamente.");
            } else {
                System.out.println("Error: La categoría no existe.");
            }
        } catch (Exception e) {
            System.out.println("Error: Entrada inválida. Asegúrate de ingresar un número entero válido.");
        }
    }

}
