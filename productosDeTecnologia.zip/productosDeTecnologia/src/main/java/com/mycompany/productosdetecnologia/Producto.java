package com.mycompany.productosdetecnologia;

public class Producto {
    String nombre;
    double precio;
    int referencia;
    int cantidad;
    int categoria;

    public Producto(String nombre, double precio, int referencia, int cantidad, int categoria) {
        this.nombre = nombre;
        this.precio = precio;
        this.referencia = referencia;
        this.cantidad = cantidad;
        this.categoria = categoria;
    }
}
